﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace punto_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = "lunes";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label1.Text = "martes";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label1.Text = "miercoles";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            label1.Text = "jueves";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            label1.Text = "viernes";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            label1.Text = "sabado";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            label1.Text = "domingo";
        }
    }
}
