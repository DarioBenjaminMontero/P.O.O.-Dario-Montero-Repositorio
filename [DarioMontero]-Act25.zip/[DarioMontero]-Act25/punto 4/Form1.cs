﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace punto_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength != 12)
            {
                textBox1.Text += "1";
            }
            else {
                label1.Text = "Demasiados digitos. no se permiten mas de 12";
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength != 12)
            {
                textBox1.Text += "0";
            }
            else
            {
                label1.Text = "Demasiados digitos. no se permiten mas de 12";
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength != 12)
            {
                textBox1.Text += "2";
            }
            else
            {
                label1.Text = "Demasiados digitos. no se permiten mas de 12";
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength != 12)
            {
                textBox1.Text += "3";
            }
            else
            {
                label1.Text = "Demasiados digitos. no se permiten mas de 12";
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength != 12)
            {
                textBox1.Text += "4";
            }
            else
            {
                label1.Text = "Demasiados digitos. no se permiten mas de 12";
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength != 12)
            {
                textBox1.Text += "5";
            }
            else
            {
                label1.Text = "Demasiados digitos. no se permiten mas de 12";
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength != 12)
            {
                textBox1.Text += "6";
            }
            else
            {
                label1.Text = "Demasiados digitos. no se permiten mas de 12";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength != 12)
            {
                textBox1.Text += "7";
            }
            else
            {
                label1.Text = "Demasiados digitos. no se permiten mas de 12";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength != 12)
            {
                textBox1.Text += "8";
            }
            else
            {
                label1.Text = "Demasiados digitos. no se permiten mas de 12";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength != 12)
            {
                textBox1.Text += "9";
            }
            else
            {
                label1.Text = "Demasiados digitos. no se permiten mas de 12";
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
