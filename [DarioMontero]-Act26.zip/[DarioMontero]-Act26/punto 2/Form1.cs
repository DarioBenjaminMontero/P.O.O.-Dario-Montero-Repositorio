﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace punto_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
  
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            int numero1, numero2;

            if (int.TryParse(textBox1.Text, out int valor))
            {
                numero1 = int.Parse(textBox1.Text);
            }
            else
            {

                Text = "Los dos valores deben ser numeros validos";
                return;
            }
            if (int.TryParse(textBox2.Text, out int valor1))
            {
                numero2 = int.Parse(textBox2.Text);
            }
            else
            {
                Text = "Los dos valores deben ser numeros validos";
                return;
            }
            int suma = numero1 + numero2;
            Text = suma.ToString();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            int numero1, numero2;

            if (int.TryParse(textBox1.Text, out int valor))
            {
                numero1 = int.Parse(textBox1.Text);
            }
            else
            {

                Text = "Los dos valores deben ser numeros validos";
                return;
            }
            if (int.TryParse(textBox2.Text, out int valor1))
            {
                numero2 = int.Parse(textBox2.Text);
            }
            else
            {
                Text = "Los dos valores deben ser numeros validos";
                return;
            }
            int resta = numero1 - numero2;
            Text = resta.ToString();
        }
    }
}
