﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace punto_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string genero = comboBox1.Text;
            string preferecia1 = "";
            string preferecia2 = "";
            string preferecia3 = "";

            if (checkBox1.Checked == true) {
                preferecia1 = checkBox1.Text;
            }
            if (checkBox2.Checked == true) {
                preferecia2 = checkBox2.Text;
            }
            if (checkBox3.Checked == true) {
                preferecia3 = checkBox3.Text;
            }

            label1.Text = "Al usuario le gusta el genero de " + genero + " y prefiere: " + preferecia1 + " " + preferecia2 + " " + preferecia3;
        }
    }
}
