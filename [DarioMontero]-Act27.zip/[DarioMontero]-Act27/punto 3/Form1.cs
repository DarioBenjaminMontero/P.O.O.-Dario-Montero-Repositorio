﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace punto_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string destino ="";
            string duracion = "";
            
             if (radioButton1.Checked == true)
            {
                destino = radioButton1.Text;
            }
            else if (radioButton2.Checked == true)
            {
                destino =radioButton2.Text;
            }
            else if (radioButton3.Checked == true) { 
            destino =radioButton3.Text;
            }
            if (comboBox1.Text == "") {
                label1.Text += " Elija una duracion de viaje";
            }
            else {
                duracion = comboBox1.Text;
            }

            if (duracion!= "" && destino!="") { 
            label1.Text = "El usuario viajará a " + destino + " en un periodo de " + duracion;
            }
        }
    }
}
