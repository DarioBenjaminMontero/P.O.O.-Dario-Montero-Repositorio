﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace punto_5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string servicio1 = "";
            string servicio2 = "";
            if (comboBox1.Text != "") {

                if (checkBox1.Checked == true) {
                    servicio1 = checkBox1.Text;
                }
                if (checkBox2.Checked == true)
                {
                    servicio2 = checkBox2.Text;
                }

                label1.Text = "Tipo de plan: " + comboBox1.Text + " Servicios extra: " + servicio1 + " " + servicio2;

            }
        }
    }
}
