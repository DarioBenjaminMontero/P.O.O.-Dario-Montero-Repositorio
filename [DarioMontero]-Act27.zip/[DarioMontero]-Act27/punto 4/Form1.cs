﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace punto_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "") {
                string opinion = "";
                if (radioButton1.Checked == true) {
                    opinion = radioButton1.Text;
                } else if (radioButton2.Checked == true) { 
                opinion = radioButton2.Text;
                }
                label2.Text = "Opinion recibida: " + textBox1.Text + " Recomendacion: " + opinion;
            }
        }
    }
}
